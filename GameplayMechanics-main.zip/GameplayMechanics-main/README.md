# Gameplay Mechanics

## Sumo Balls (With Bonus Features)

Scene -> Prototype 4

Game link -> [Sumo Balls](https://play.unity.com/mg/other/sumoballs-2)

![Sumo Balls](./sumoballs.png)

## Challenge 4

Scene -> Challenge 4

![Challenge 4](./challenge4.png)
